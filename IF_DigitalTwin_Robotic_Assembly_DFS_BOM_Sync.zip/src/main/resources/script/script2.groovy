package cpi.scripts

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

/**
 * Depth-First Search (DFS) Circular Dependency Detection
 * 
 * Štiti S/4HANA Manufacturing bazu od kružnih zavisnosti (Deadlock).
 * Boje čvorova u DFS stablu:
 * 0 = WHITE (neposećen)
 * 1 = GRAY (trenutno na rekurzivnom steku)
 * 2 = BLACK (u potpunosti istražen)
 */
Message processData(Message message) {
    String rawBomJson = message.getProperty("Prop_Raw_BOM_Payload") as String
    String rootParent = message.getProperty("Prop_Parent_Material") as String
    
    def jsonSlurper = new JsonSlurper()
    def bomChanges = jsonSlurper.parseText(rawBomJson)

    // 1. Izgradnja usmerenog grafa (Adjacency List)
    Map<String, List<String>> graph = [:].withDefault { [] }

    bomChanges.each { item ->
        String parent = item.parentMaterialId ?: rootParent
        String child = item.componentMaterialId
        if (child) {
            graph[parent].add(child)
        }
    }

    // 2. DFS Cycle Detection sa praćenjem putanje
    Map<String, Integer> visited = [:]
    List<String> cyclePath = []
    boolean hasCycle = false

    def dfs
    dfs = { String node, List<String> currentPath ->
        visited[node] = 1 // Mark as GRAY
        currentPath.add(node)

        for (String neighbor : graph[node]) {
            if (visited[neighbor] == 1) { // Kružna zavisnost pronađena (GRAY čvor ponovo posećen)
                hasCycle = true
                currentPath.add(neighbor)
                cyclePath.addAll(currentPath)
                return true
            }
            if (visited[neighbor] == null || visited[neighbor] == 0) {
                if (dfs(neighbor, currentPath)) {
                    return true
                }
            }
        }

        currentPath.remove(currentPath.size() - 1)
        visited[node] = 2 // Mark as BLACK
        return false
    }

    // Pokreni DFS za sve čvorove u grafu
    for (String node : graph.keySet()) {
        if (visited[node] == null || visited[node] == 0) {
            if (dfs(node, [])) {
                break
            }
        }
    }

    message.setProperty("Prop_Circular_Cycle_Found", hasCycle.toString())

    if (hasCycle) {
        String cycleReport = cyclePath.join(" ──► ")
        message.setProperty("Prop_Detected_Cycle_Path", cycleReport)
        message.setHeader("X-BOM-Integrity-Status", "CIRCULAR_DEPENDENCY_DETECTED")
    } else {
        message.setProperty("Prop_Detected_Cycle_Path", "NONE")
        message.setHeader("X-BOM-Integrity-Status", "VALID_ACYCLIC_GRAPH")
    }

    return message
}